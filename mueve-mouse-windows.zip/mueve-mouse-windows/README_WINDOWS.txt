MUEVE MOUSE - INSTALACIÓN EN WINDOWS
======================================

Este paquete contiene Mueve Mouse para Windows.

INSTALACIÓN:
1. Extraer el archivo ZIP
2. Ejecutar como administrador: INSTALAR.bat
3. La aplicación se instalará automáticamente

DESINSTALACIÓN:
1. Ejecutar como administrador: DESINSTALAR.bat
2. La aplicación se desinstalará completamente

EJECUCIÓN:
- Desde el escritorio: "Mueve Mouse"
- Desde el menú inicio: Buscar "Mueve Mouse"
- Directamente: "%PROGRAMFILES%\Mueve Mouse\MueveMouse.exe"

NOTAS:
- Se requiere permisos de administrador para la instalación
- La aplicación aparecerá en el escritorio y menú inicio
- Funciona en Windows 7, 8, 10 y 11
- No requiere instalación de dependencias adicionales

SOLUCIÓN DE PROBLEMAS:
- Si el antivirus bloquea la aplicación, agregar a excepciones
- Si no se instala, ejecutar como administrador
- Si no aparece en el menú, reiniciar el explorador de Windows
