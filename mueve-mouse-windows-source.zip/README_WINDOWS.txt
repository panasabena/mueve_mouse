🪟 MUEMOUSE PARA WINDOWS - INSTALACION DESDE CODIGO FUENTE
============================================================

Este paquete contiene el código fuente de MueveMouse y se puede compilar
directamente en tu sistema Windows.

📋 REQUISITOS PREVIOS:
- Windows 7/8/10/11 (64-bit)
- Python 3.7 o superior
- Conexión a internet para descargar dependencias

🚀 INSTALACION AUTOMATICA:
1. Descarga y extrae este paquete ZIP
2. Ejecuta INSTALAR.bat como administrador
3. El instalador verificará Python y pip
4. Instalará todas las dependencias necesarias
5. Compilará MueveMouse en tu sistema
6. Creará un acceso directo en el escritorio

🔧 INSTALACION MANUAL:
Si prefieres instalar manualmente:

1. Instalar Python desde https://python.org
2. Abrir Command Prompt como administrador
3. Navegar al directorio del paquete
4. Ejecutar: pip install -r requirements.txt
5. Ejecutar: pip install pyinstaller
6. Ejecutar: python build.py

📁 ARCHIVOS INCLUIDOS:
- mueve_mouse.py: Código fuente principal
- requirements.txt: Dependencias de Python
- mueve_mouse.spec: Configuración de PyInstaller
- build.py: Script de construcción
- INSTALAR.bat: Instalador automático
- DESINSTALAR.bat: Desinstalador
- README.md: Documentación completa

🎯 USO:
- Ejecuta MueveMouse.bat desde el escritorio
- O navega a dist/ y ejecuta MueveMouse.exe

❓ SOLUCION DE PROBLEMAS:
- Si Python no se encuentra, reinstala Python marcando "Add to PATH"
- Si hay errores de dependencias, ejecuta: pip install --upgrade pip
- Para problemas de permisos, ejecuta como administrador

🔗 ENLACES UTILES:
- Python: https://python.org
- PyInstaller: https://pyinstaller.org
- PyAutoGUI: https://pyautogui.readthedocs.io

📞 SOPORTE:
Si tienes problemas, consulta:
- README.md para documentación completa
- GitHub: https://github.com/panasabena/mueve_mouse
